/** 
 * Class RockPaperScissors.  Plays repeated games of Rock Paper Scissors with a user 
 * @author Your Name
 * @date The date
 * */

import java.util.LinkedList;
import java.util.Scanner;
import java.util.Random;

public class RockPaperScissors
{
  
  public static void main( String[] args )
  {
    int initialCapacity = 5;
    // Store the user's move history
    String[] userMoves = new String[initialCapacity];  
    // Store the System's move history
    LinkedList<String> systemMoves = new LinkedList<String>();  
    
    
  
  }
  
  
}